cargo build --release --target $INPUT_TARGET
